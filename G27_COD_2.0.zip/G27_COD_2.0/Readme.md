#Bienvenido a EATNOW
-Descraga MAMP,XAMP O WAMP
-Introduce la carpeta de G27_COD_2.0 en dentro de la carpeta Apache2/htdocs/
-Importa eatnow.sql dentro de php_my_admin
-cambia la contraseña en el archivo de bd_conexión.php( G27_COD_2.0/includes/funciones/bd_conexión.php) por la que hayas introducido en phpmyadmin
-abre tu localhost y en la url busca el nombre de la carpeta G27_COD_2.0
-navega libremente 
