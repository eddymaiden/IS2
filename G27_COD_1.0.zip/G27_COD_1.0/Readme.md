#Bienvenido a EATNOW
pincha en el index.html para acceder a la pagina web,
estamos en el ciclo 1 y todavía faltan muchas funcionalidades a nivel de backend, el frontend esta prácticamente acabado, disfruta de la navegación por el entorno